<div class="content-wrapper">
    <div class="container">
        <h1>Do you want to delete?</h1>
        <h3><?php echo $post['title']; ?></h3>
        <form action="./index.php?page=delete" method="post">
            <input type="hidden" name="id" value="<?php echo $post['id']; ?>" />
            <div class="form-group">
                <input type="submit" value="Delete" class="btn btn-danger" />
                <a class="btn btn-default" href="index.php?page=list">Cancel</a>
            </div>
        </form>
    </div>
</div>