
<div class="content-wrapper">
<div class="col-12 col-md-12">
  <div class="row">
      <div class="col-12">
          <h1>Add Posts</h1>
      </div>
      <div class="col-12">
          <form method="post">
              <div class="form-group">
                  <label>Title</label>
                  <input type="text" class="form-control" name="title"  placeholder="Nhập title" required>
              </div>
              <div class="form-group">
                  <label>Teaser</label>
                  <input type="text" class="form-control" name="teaser" placeholder="Teaser" required>
              </div>
              <div class="form-group">
                  <label>Teaser image</label>
                  <input type="text" class="form-control" name="teaser_img" placeholder="Teaser image" required>
              </div>
              <div class="form-group">
                  <label>Content</label>
                  <input type="text" class="form-control" name="content" placeholder="Content" required>
              </div>
              <div class="form-group">
                  <label>Author</label>
                  <input type="text" class="form-control" name="author" placeholder="Author" required>
              </div>
              <div class="form-group">
                  <label>Created</label>
                  <input type="date" class="form-control" name="created" placeholder="Creat" required>
              </div>
              <div class="form-group">
                  <label>category_id</label>
                  <input type="number" class="form-control" name="category_id" placeholder="category_id" required>
              </div>
              <div class="form-group">
                  <label>user_id</label>
                  <input type="number" class="form-control" name="user_id" placeholder="user_id" required>
              </div>
              <button type="submit" class="btn btn-primary">Thêm mới</button>
              <button class="btn btn-secondary" onclick="window.history.go(-1); return false;">Hủy</button>
          </form>       
     </div>   
   </div> 
</div> 
</div>