<?php
namespace Controller;

use Model\DataBase;
use Model\Post;
use Model\PostDB;

class PostController {
    public $postDB;
    public function __construct()
    {
        $connection = new DataBase();
        $this->postDB = new PostDB($connection->connect());
    }
    public function add()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            include 'Src/View/admin/pages/post/add.php';
        } else {
            $title = $_POST['title'];
            $teaser = $_POST['teaser'];
            $teaser_img = $_POST['teaser_img'];
            $content = $_POST['content'];
            $author = $_POST['author'];
            $created = $_POST['created'];
            $category_id = $_POST['category_id'];
            $user_id = $_POST['user_id'];
            $post = new Post($title, $teaser,$teaser_img, $content, $author, $created,$category_id,$user_id);
            $this->postDB->add($post);
            include 'Src/View/admin/pages/post/list.php';
        }
    }
    public function list() {
        $postList = $this->postDB->getAll();
        include 'Src/View/admin/pages/post/list.php';
    }
    public function view()
    {
        
            $id = $_GET['id'];
            $postDetail = $this->postDB->getDetail($id);
            include 'Src/View/admin/pages/post/view.php';
        
    }
    public function edit()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $id = $_GET['id'];
            $posts = $this->postDB->getById($id);
            include 'Src/View/admin/pages/post/edit.php';
        } else {
            $id = $_POST['id'];
            $post = new Post($_POST['title'],$_POST['teaser'],$_POST['teaser_img'],$_POST['content'],$_POST['author'],$_POST['created'],$_POST['category_id'],$_POST['user_id']);
            $this->postDB->update($id, $post);
            include 'Src/View/admin/pages/post/edit.php';
        }
    }
    public function delete()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $id = $_GET['id'];
            $post = $this->postDB->getById($id);
            include 'Src/View/admin/pages/post/delete.php';
        } else {
            $id = $_POST['id'];
            $this->postDB->delete($id);
            
        }
    }
    public function index()
    {
        include 'Src/View/admin/layouts/home.php';
    }
}