<?php

use Controller\PostController;

require_once "Src/Model/DBConnection.php";
require_once "Src/Model/Post/Post.php";
require_once "Src/Model/Post/PostDB.php";
require_once "Src/Controller/PostController.php";
require_once "Src/View/admin/layouts/header.php";

?>
<?php
$postController = new PostController();
$page = isset($_REQUEST['page']) ? $_REQUEST['page'] : '';
switch ($page) {
    case 'add':
        $postController->add();
        break;
    case 'list':
        $postController->list();
        break;
    case 'view':
        $postController->view();
        break;
    case 'delete':
        $postController->delete();
        break;
    case 'edit':
        $postController->edit();
        break;
    default:
        $postController->index();
        break;
}
require_once "Src/View/admin/layouts/footer.php";
?>
